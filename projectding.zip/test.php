<?php

$db = mysqli_connect("localhost", "root", "", "photo");
include_once('upload.php');
?>


<!DOCTYPE html>
<html>
<head>
	<title> kukdzgflcbzux.dkvbc </title>
</head>
<body>
	 <?php
    while ($row = mysqli_fetch_array($result)) {
      echo "<div class='img_div'>";
        echo "<img src='images/".$row['image']."' >";
        echo "<p>".$row['image_text']."</p>";
      echo "</div>";
    }
  ?>

</style>
</body>
</html>