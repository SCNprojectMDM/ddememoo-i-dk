<?php
    

  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "photo");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
    // Get image name
    $image = $_FILES['image']['name'];
    // Get text
    $image_text = mysqli_real_escape_string($db, $_POST['image_text']);
    // get auteur
    $auteur = $_SESSION['username'];  

    // image file directory
    $target = "images/".basename($image);

    $sql = "INSERT INTO images (image, image_text, auteur) VALUES ('$image', '$image_text', '$auteur')";
    // execute query
    mysqli_query($db, $sql);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
    }else{
      $msg = "Failed to upload image";
    }
  }
  $result = mysqli_query($db, "SELECT * FROM images");

  echo "$msg";
?>

<style type="text/css">
   #content{
    width: 50%;
    margin: 20px auto;
    border: 1px solid #cbcbcb;

   }
   form{
    width: 50%;
    margin: 20px auto;
   }
   form div{
    margin-top: 5px;
   }
   .img_div{
    width: 20%;
    height: 35%;
    padding: 5px;
    margin-left: 4%;
    margin-bottom: 2%;
    margin-top: 2%;
    border: 1px solid #cbcbcb;
    background-color: rgba(0,0,255,0.7);
    float: left;

   }
   .img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
   
    width: 100%;
    height: 65%;
   }
  
</style>

<?php
    while ($row = mysqli_fetch_array($result)) {
      echo "<div class='img_div'>";
        echo "<img src='images/".$row['image']."' >";
        echo "<h3>".$row['image_text']."</h3>";
        echo "<p>Made by : ".$row['auteur']."</p>";
        ?>
        <a href=" images/<?php echo $row['image']; ?>" download><?php echo "<h4><div class='glyphicon glyphicon-download'> DOWNLOAD</div></h4></a>";
        
        

       
      echo "</div>";

    }
  ?>
<br>
<br><br>
<br><br>
<br> 