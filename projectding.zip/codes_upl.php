<?php
include_once('bovenstuk.php');	
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles.css">
<title>Image Upload</title>
<style type="text/css">
   #content{ 
    width: 50%;
    margin: 20px auto;
    border: 1px solid black;
   }
   form{
    width: 50%;
    margin: 20px auto;
   }
   form div{
    margin-top: 5px;
   }
   .img_div{
    width: 80%;
    padding: 5px;
    margin: 15px auto;
    border: 1px solid black;
   }
   .img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
    float: left;
    margin: 5px;
    width: 300px;
    height: 140px;
   }
  
</style>
</head>
<body>
<div id="content">
  <form method="POST" action="codes.php" enctype="multipart/form-data">
    <input type="hidden" name="size" value="1000000">
    <h4>Select a Thumbnail</h4>
    <div>
      <input type="file" name="image" required>
    </div>
    <div>
      <textarea 
      required 
        id="text" 
        cols="30" 
        rows="1" 
        name="image_text" 
        placeholder="Title of code..."></textarea>
    </div>
    <div>
      <button type="submit" name="upload">SUBMIT</button>
    </div>

  </form>
</div>
</body>
</html>