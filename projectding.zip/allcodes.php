<?php
    
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "photo");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
    // Get image name
    $image = $_FILES['image']['name'];
    // Get text
    $image_text = mysqli_real_escape_string($db, $_POST['image_text']);
    // get file
    $code = $_FILES['image']['name'];
    // get auteur
    $auteur = $_SESSION['username'];  

    // image file directory
   
    $target = "codes/".basename($code);
    

    $sql = "INSERT INTO codes (image, image_text, auteur) VALUES ('$image', '$image_text', '$auteur')";
    // execute query
    mysqli_query($db, $sql);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
    }else{
      $msg = "Failed to upload image";
    }
  }

  
  $result = mysqli_query($db, "SELECT * FROM codes");

 
?>

<style type="text/css">
   #content{
    width: 50%;
    margin: 20px auto;
    border: 1px solid #cbcbcb;
    background-color: #3d5afe;


   }
   form{
    width: 50%;
    margin: 20px auto;
   }
   form div{
    margin-top: 5px;
   }
   .img_div{
    width: 20%;
    height: 35%;
    padding: 5px;
    margin-left: 4%;
    margin-bottom: 2%;
    margin-top: 2%;
    border: 2px solid black;
    background-color: #3d5afe;
    float: left;
    border-radius: 1%;

   }
   .img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
   
    width: 100%;
    height: 65%;
   }
  
</style>

<?php
    while ($row = mysqli_fetch_array($result)) {
      echo "<div class='img_div'>";
        echo "<img src='codes/".$row['image']."' >";
        echo "<h3>".$row['image_text']."</h3>";
        echo "<p>Made by : ".$row['auteur']."</p>";
        ?>
        <a href=" codes/<?php echo $row['code']; ?>" download><?php echo "<h4><div class='glyphicon glyphicon-download'> DOWNLOAD</div></h4></a>";
        
        

       
      echo "</div>";

    }
  ?>
<br>
<br><br>
<br><br>
<br> 