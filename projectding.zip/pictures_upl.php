<?php
include_once('bovenstuk.php');



  // Create database connection
  $db = mysqli_connect("localhost", "root", "", "photo");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
    // Get image name
    $image = $_FILES['image']['name'];
    // Get text
    $image_text = mysqli_real_escape_string($db, $_POST['image_text']);
    // get auteur
    $auteur = $_SESSION['username'];

    // image file directory
    $target = "images/".basename($image);

    $sql = "INSERT INTO images (image, image_text, auteur) VALUES ('$image', '$image_text', '$auteur')";
    // execute query
    mysqli_query($db, $sql);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      $msg = "Image uploaded successfully";
    }else{
      $msg = "Failed to upload image";
    }
  }
  $result = mysqli_query($db, "SELECT * FROM images");
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles.css">
<title>Image Upload</title>
<style type="text/css">
   #content{ 
    width: 50%;
    margin: 20px auto;
    border: 1px solid black;
   }
   form{
    width: 50%;
    margin: 20px auto;
   }
   form div{
    margin-top: 5px;
   }
   .img_div{
    width: 80%;
    padding: 5px;
    margin: 15px auto;
    border: 1px solid black;
   }
   .img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
    float: left;
    margin: 5px;
    width: 300px;
    height: 140px;
   }
  
</style>
</head>
<body>
<div id="content">
  <form method="POST" action="pictures.php" enctype="multipart/form-data">
    <input type="hidden" name="size" value="1000000">
    <div>
      <input type="file" name="image" required>
    </div>
    <div>
      <textarea 
      required 
        id="text" 
        cols="30" 
        rows="1" 
        name="image_text" 
        placeholder="Title of image..."></textarea>
    </div>
    <div>
      <button type="submit" name="upload">SUBMIT</button>
    </div>
  </form>
</div>
</body>
</html>