<?php
// Initialize the session
session_start();
 
// If session variable is not set it will redirect to login page
if(!isset($_SESSION['username']) || empty($_SESSION['username'])){
  header("location: login.php");
  exit;
}
?>
 
<?php
include_once('bovenstuk.php');
?>

<div class="container section-ourTeam">
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12 text-center">
			<h1>The Team</h1>
		</div>
	</div>
	<div class="row">
		<div class="col-md-4 col-sm-4 col-xs-12">
			<div class="row section-info ourTeam-box text-center">
				<br><br><br><br>
				<div class="col-md-12 section1">
					<img src="img/pp.jpg">
				</div>
				<div class="col-md-12 section2">
					<p>Dominik Meenen</p><br>
					<h2></h2><br>
				</div>
				<div class="col-md-12 section3">
					<p>
				
					</p>
				</div>
				<div class="col-md-12 section4">
					<a href="mailto:info@original-mike.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12">
			<div class="row section-succes ourTeam-box text-center">
				<div class="col-md-12 section1">
					<img src="img/pp.jpg">
				</div>
				<div class="col-md-12 section2">
					<p>ᴼᴿᴵᴳᴵᴻᴬᴸ Mike</p><br>
					<h2></h2><br>
				</div>
				<div class="col-md-12 section3">
					<p>
			
					</p>
				</div>
				<div class="col-md-12 section4">
					<a href="mailto:dominikmeenen@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
		<div class="col-md-4 col-sm-4 col-xs-12">
			<div class="row section-danger ourTeam-box text-center">
				<br><br><br><br>
				<div class="col-md-12 section1">
					<img src="img/pp.jpg">
				</div>
				<div class="col-md-12 section2">
					<p>Mike Folkersma</p><br>
					<h2></h2><br>
				</div>
				<div class="col-md-12 section3">
					<p>
				
					</p>
				</div>
				<div class="col-md-12 section4">
					<a href="mailto:crouw2@hotmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
				</div>
			</div>
		</div>
	</div>
</div>
<hr>
<?php
include_once('onderstuk.php');
?>