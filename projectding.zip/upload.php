<?php
include_once('bovenstuk.php');
include_once('upload.php');



?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="styles.css">
<title>Image Upload</title>
<style type="text/css">
   #content{ 
    width: 50%;
    margin: 20px auto;
    border: 1px solid black;
   }
   form{
    width: 50%;
    margin: 20px auto;
   }
   form div{
    margin-top: 5px;
   }
   .img_div{
    width: 80%;
    padding: 5px;
    margin: 15px auto;
    border: 1px solid black;
   }
   .img_div:after{
    content: "";
    display: block;
    clear: both;
   }
   img{
    float: left;
    margin: 5px;
    width: 300px;
    height: 140px;
   }
  
  h2 {
    text-align: center;
  }
</style>
</head>
<body>

<div id="home2upl">
          <div class="landing-textupl">
            <h2>SELECTEER EEN CATEGORIE OM DOOR TE GAAN</h2>
              <a href="tools_upl.php"><span class="fa fa-wrench"><br>Tools</span></a>
              <a href="vehicles_upl.php"><span class="fa fa-car"><br>Vehicles</span></a>
              <a href="aircrafts_upl.php"><span class="fa fa-fighter-jet"><br>Aircrafts</span></a>
              <a href="codes_upl.php"><span class="fa fa-code"><br>Codes</span></a>
              <a href="hacks_upl.php"><span class="fa fa-eye"><br>Hacks</span></a>
              <a href="music_upl.php"><span class="fa fa-volume-up"><br>Music</span></a>
              <a href="pictures_upl.php"><span class="fa fa-photo"><br>Pictures</span></a>
              <a href="nsfw.php_upl"><span class="fa fa-minus-circle"><br>NSFW</span></a>
          </div>
        </div>
</body>

</html>