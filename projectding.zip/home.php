<?php
	include_once('bovenstuk.php');
	?>
	<div class="test">
		<br><br><br><br><br><br>
	</div>
	<?php
	include_once('onderstuk.php');