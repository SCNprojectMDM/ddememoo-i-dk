<?php 
$db = mysqli_connect("localhost", "root", "", "photo");

include_once('upload.php');
?>


<!DOCTYPE html>
<html>
<head>
	<title>Succes</title>
	<meta http-equiv="refresh" content="3; url=upload.php" />
</head>
<body>
<h1>UPLOAD SUCCESFULL! CHECK <a href="pictures.php">PICTURES</a></h1>
<style>
	h1 {
		text-align: center;
	}
</style>
</body>
</html>